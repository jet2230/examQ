# DNF App Center Flatpak Cache Bug

## Bug: Stale "Finish Update" Indicators

DNF App Center (Nobara/Fedora) v0.1.4 has a known bug where the updater service
(`dnf-app-center-updater`) fails to properly rebuild its cache after Flatpak updates.
This leaves stale "Finish update" or "Update available" buttons for apps that are
already current.

### Symptoms

- Flatpak GUI shows "Update available" or "Finish update" for an app
- `flatpak update` returns "Nothing to do"
- `flatpak info <app-id>` shows latest version
- DNF App Center process (`/usr/bin/python3 /usr/bin/dnf-app-center-updater`) hangs
  with no output, never completing cache rebuild

### Root Cause

The updater service hangs when scanning Flatpak remotes — specifically when it
encounters remotes without AppStream data (e.g., leftover third-party `.repo`
directories). It writes nothing to `~/.cache/dnf-app-center/` and never completes.

### Evidence

Session 2026-05-10:
- `dnf-app-center-updater` ran for 60+ seconds with no output
- `~/.cache/dnf-app-center/` remained empty throughout
- Process exited silently (no output, no cache written)
- `flatpak remotes` showed `resolve-repo` pointing to a Davinci Resolve `.repo`
  directory at `/home/obo/Downloads/DaVinci_Resolve_20.2.1_Linux/.repo`
- This remote had no `appstream` or `appstream2` ref, causing downstream errors:
  ```
  Error updating appstream2: No such ref 'appstream2/x86_64' in remote resolve-repo
  Error updating appstream: No such ref 'appstream/x86_64' in remote resolve-repo
  ```

### Fix

1. Remove broken remotes: `flatpak remote-delete resolve-repo`
2. Clear cache: `rm -rf ~/.cache/dnf-app-center/*`
3. Kill hanging process: `kill <pid>` (find with `ps aux | grep dnf-app`)
4. Reopen DNF App Center

If it still hangs after this, the updater service itself may be broken in this
version. Use `flatpak update` from terminal as a reliable alternative.

### App Center Version

Installed: `dnf-app-center-0.1.4-1.fc43.noarch`
Repository: `nobara-updates` (Copr - gloriouseggroll)
Source: https://github.com/Nobara-Project/dnf-app-center

### Workaround for Users

Until the bug is patched, use terminal for Flatpak updates:
```
flatpak update --assumeyes
```

This bypasses DNF App Center entirely and is reliable.
