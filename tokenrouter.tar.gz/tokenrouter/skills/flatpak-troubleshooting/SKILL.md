---
name: flatpak-troubleshooting
description: "Diagnosing and fixing Flatpak issues: stale update indicators, hung updaters, broken remotes, and EOL runtime warnings."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [flatpak, package-management, troubleshooting, dnf-app-center, fedora, nobara]
    related_skills: [systematic-debugging]
---

# Flatpak Troubleshooting

Diagnosing and fixing common Flatpak issues — stale update indicators, hung updaters, broken remotes, and EOL runtime warnings.

## 1. "Update" button shows but `flatpak update` says "Nothing to do"

This is almost always a **GUI cache issue**, not a real pending update.

**Step 1 — Verify the real state:**
```
flatpak update
```
If it says "Nothing to do", the apps are current.

**Step 2 — Clear the GUI cache:**

- **GNOME Software:**
  ```
  rm -rf ~/.cache/gnome-software/*
  ```
  Then restart GNOME Software.

- **DNF App Center (Nobara/Fedora):**
  ```
  rm -rf ~/.cache/dnf-app-center/*
  ```
  Then quit and reopen DNF App Center.

**Step 3 — If DNF App Center hangs rebuilding cache (known bug v0.1.4):**
```
flatpak remote-delete resolve-repo  # or any stale third-party remote
rm -rf ~/.cache/dnf-app-center/*
```
Then reopen the app. If it still hangs, the updater service may be stuck on a broken remote — check for hanging processes:
```
ps aux | grep -iE 'appcenter|dnf-app' | grep -v grep
```
Kill any hanging ones, clear cache again, and reopen.

**Workaround:** Use `flatpak update` from terminal for reliable updates.

## 2. `flatpak update` shows apps but GUI doesn't

**Cause:** The update button contacts the app's remote directly (bypassing system cache), while the system updater may skip third-party remotes or have stale metadata.

**Fix:**
```
flatpak update --assumeyes
```
This catches ALL remotes, not just Flathub.

## 3. Third-party remote causing hangs or errors

**Symptoms:** Updater hangs indefinitely, or errors like "No such ref appstream2/x86_64".

**Diagnose:**
```
flatpak remotes
```

**Fix:** Identify the problematic remote (often a leftover from a removed app) and remove it:
```
flatpak remote-delete <remote-name>
```

## 4. EOL runtime warnings flooding output

**Symptoms:** "is end-of-life" warnings for `org.freedesktop.Platform` and `org.kde.Platform` branches.

**These are informational** — Flatpak can't auto-update pinned EOL runtimes. They're not blocking updates.

**To clean up:** Update or uninstall the affected apps. The runtimes will be replaced.

## 5. Appstream metadata errors

**Symptoms:** "Error updating appstream2: No such ref 'appstream2/x86_64'".

**Cause:** A Flatpak remote (usually a leftover third-party one) doesn't have AppStream data.

**Fix:**
```
flatpak remote-delete <broken-remote>
```

## Quick Reference Commands

| Command | Purpose |
|---------|---------|
| `flatpak update` | Check for all updates across all remotes |
| `flatpak update --assumeyes` | Apply all updates non-interactively |
| `flatpak remotes` | List all configured remotes |
| `flatpak list --app` | List installed apps with versions |
| `flatpak info <app-id>` | Get detailed info on a specific app |
| `flatpak remote-ls <remote>` | List available packages from a remote |
| `flatpak uninstall --unused` | Remove orphaned runtimes |
| `rm -rf ~/.cache/gnome-software/*` | Clear GNOME Software cache |
| `rm -rf ~/.cache/dnf-app-center/*` | Clear DNF App Center cache |

## Session Details

See `references/dnf-app-center-bug.md` for the full session transcript and
technical details of the DNF App Center caching bug discovered 2026-05-10.

## Pitfalls

- **DNF App Center v0.1.4 updater hangs** when scanning Flatpak remotes. It may never finish rebuilding its cache, leaving stale "Finish update" indicators permanently. Do NOT wait for it — use `flatpak update` from terminal instead.
- **Broken third-party remotes** (e.g., leftover Davinci Resolve `.repo` directories) can cause both `flatpak remote-ls` and DNF App Center to hang or error out. Always check `flatpak remotes` first.
- **"Update" in GUI ≠ update available.** The GUI update button may contact remotes directly and show "update available" when the real issue is stale appstream metadata or a hung updater service. Always verify with `flatpak update` first.
